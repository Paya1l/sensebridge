// content.js — SenseBridge content script

(function () {
  if (window.__senseBridgeLoaded) return;
  window.__senseBridgeLoaded = true;

  // ── State ──────────────────────────────────────────
  let hoverEnabled   = false;
  let focusEnabled   = false;
  let captionActive  = false;
  let recognition    = null;
  let captionBox     = null;
  let hoverTimeout   = null;

  // ── Utilities ──────────────────────────────────────
  function getPageText() {
    const sel = window.getSelection()?.toString()?.trim();
    if (sel && sel.length > 10) return sel;
    const main =
      document.querySelector('main, article, [role="main"]') ||
      document.body;
    return (main.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 8000);
  }

  function speak(text, rate = 1) {
    window.speechSynthesis.cancel();
    if (!text) return;
    const u = new SpeechSynthesisUtterance(text);
    u.rate = rate;
    u.lang = document.documentElement.lang || 'en-US';
    window.speechSynthesis.speak(u);
  }

  function stopSpeech() {
    window.speechSynthesis.cancel();
  }

  // ── Image alt reader ───────────────────────────────
  function readImages(rate) {
    const imgs = Array.from(document.querySelectorAll('img'));
    const descriptions = imgs
      .map(img => {
        const alt = img.alt?.trim();
        const title = img.title?.trim();
        const aria = img.getAttribute('aria-label')?.trim();
        return aria || alt || title || null;
      })
      .filter(Boolean);

    if (!descriptions.length) {
      speak('No image descriptions found on this page.', rate);
      return;
    }
    speak(
      `Found ${descriptions.length} image${descriptions.length > 1 ? 's' : ''}. ${descriptions.join('. ')}`,
      rate
    );
  }

  // ── High Contrast ──────────────────────────────────
  function setContrast(on) {
    let el = document.getElementById('sb-contrast-style');
    if (on) {
      if (!el) {
        el = document.createElement('style');
        el.id = 'sb-contrast-style';
        document.head.appendChild(el);
      }
      el.textContent = `
        html, body { background: #000 !important; color: #fff !important; }
        a { color: #FFFF00 !important; }
        button, input, select, textarea {
          background: #111 !important;
          color: #fff !important;
          border-color: #FFFF00 !important;
        }
        img { filter: contrast(1.2) !important; }
      `;
    } else {
      el?.remove();
    }
  }

  // ── Dark Mode ──────────────────────────────────────
  function setDark(on) {
    let el = document.getElementById('sb-dark-style');
    if (on) {
      if (!el) {
        el = document.createElement('style');
        el.id = 'sb-dark-style';
        document.head.appendChild(el);
      }
      el.textContent = `
        html {
          filter: invert(1) hue-rotate(180deg) !important;
        }
        img, video, canvas, svg, [style*="background-image"] {
          filter: invert(1) hue-rotate(180deg) !important;
        }
      `;
    } else {
      el?.remove();
    }
  }

  // ── Font Size ──────────────────────────────────────
  function setFontSize(pct) {
    let el = document.getElementById('sb-font-style');
    if (!el) {
      el = document.createElement('style');
      el.id = 'sb-font-style';
      document.head.appendChild(el);
    }
    el.textContent = `html { font-size: ${pct}% !important; }`;
  }

  // ── Focus Highlight ────────────────────────────────
  function setFocus(on) {
    let el = document.getElementById('sb-focus-style');
    if (on) {
      if (!el) {
        el = document.createElement('style');
        el.id = 'sb-focus-style';
        document.head.appendChild(el);
      }
      el.textContent = `
        *:focus, *:focus-visible {
          outline: 4px solid #7B72D6 !important;
          outline-offset: 3px !important;
          border-radius: 4px !important;
          box-shadow: 0 0 0 6px rgba(123,114,214,0.3) !important;
        }
      `;
    } else {
      el?.remove();
    }
  }

  // ── Hover to Read ──────────────────────────────────
  function onHover(e) {
    if (!hoverEnabled) return;
    clearTimeout(hoverTimeout);
    hoverTimeout = setTimeout(() => {
      const el = e.target;
      const text =
        el.getAttribute('aria-label') ||
        el.getAttribute('title') ||
        el.getAttribute('alt') ||
        el.innerText?.trim().slice(0, 200);
      if (text && text.length > 2) speak(text, 1);
    }, 600);
  }

  document.addEventListener('mouseover', onHover);

  function setHover(on, rate) {
    hoverEnabled = on;
  }

  // ── Live Captions ──────────────────────────────────
  function createCaptionBox() {
    if (captionBox) return;
    captionBox = document.createElement('div');
    captionBox.id = 'sb-caption-box';
    Object.assign(captionBox.style, {
      position:     'fixed',
      bottom:       '20px',
      left:         '50%',
      transform:    'translateX(-50%)',
      maxWidth:     '720px',
      width:        '90%',
      background:   'rgba(19, 17, 31, 0.95)',
      color:        '#EDE9FF',
      padding:      '14px 20px',
      borderRadius: '16px',
      fontSize:     '18px',
      fontWeight:   '600',
      lineHeight:   '1.5',
      zIndex:       '2147483647',
      boxShadow:    '0 8px 40px rgba(0,0,0,0.6)',
      border:       '1.5px solid #2E2855',
      transition:   'opacity 0.3s',
      fontFamily:   'system-ui, sans-serif',
      pointerEvents:'none',
      textAlign:    'center',
    });
    document.body.appendChild(captionBox);
  }

  function removeCaptionBox() {
    captionBox?.remove();
    captionBox = null;
  }

  function toggleCaptions(on) {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      console.warn('[SenseBridge] SpeechRecognition not supported');
      return;
    }

    if (!on) {
      recognition?.stop();
      recognition = null;
      captionActive = false;
      removeCaptionBox();
      return;
    }

    createCaptionBox();
    captionActive = true;
    recognition = new SR();
    recognition.continuous    = true;
    recognition.interimResults = true;
    recognition.lang = document.documentElement.lang || 'en-US';

    recognition.onresult = (ev) => {
      let interim = '', final = '';
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        const t = ev.results[i][0].transcript;
        if (ev.results[i].isFinal) final += t;
        else interim += t;
      }
      if (captionBox) {
        captionBox.textContent = final || interim;
        captionBox.style.opacity = (final || interim) ? '1' : '0.4';
      }
    };

    recognition.onerror = () => {};
    recognition.onend = () => {
      if (captionActive) recognition.start(); // auto-restart
    };

    recognition.start();
  }

  // ── Floating SenseBridge badge on page ────────────
  function injectBadge() {
    if (document.getElementById('sb-badge')) return;
    const badge = document.createElement('div');
    badge.id = 'sb-badge';
    badge.title = 'SenseBridge active';
    Object.assign(badge.style, {
      position:     'fixed',
      top:          '12px',
      right:        '12px',
      width:        '36px',
      height:       '36px',
      borderRadius: '50%',
      background:   'linear-gradient(135deg, #534AB7, #1D9E75)',
      zIndex:       '2147483646',
      cursor:       'pointer',
      boxShadow:    '0 4px 16px rgba(83,74,183,0.4)',
      display:      'flex',
      alignItems:   'center',
      justifyContent: 'center',
      transition:   'transform 0.2s',
    });
    badge.innerHTML = `<svg width="20" height="20" viewBox="0 0 48 48" fill="none">
      <path d="M4 32 Q24 6 44 32" stroke="white" stroke-width="3" fill="none" stroke-linecap="round"/>
      <circle cx="24" cy="32" r="4" fill="white"/>
    </svg>`;
    badge.addEventListener('mouseenter', () => badge.style.transform = 'scale(1.1)');
    badge.addEventListener('mouseleave', () => badge.style.transform = 'scale(1)');
    badge.addEventListener('click', () => speak(getPageText(), 1));
    document.body.appendChild(badge);
  }

  injectBadge();

  // ── Restore saved prefs ────────────────────────────
  chrome.storage.local.get('sbPrefs', res => {
    if (!res.sbPrefs) return;
    const p = res.sbPrefs;
    if (p.contrast)  setContrast(true);
    if (p.dark)      setDark(true);
    if (p.focus)     setFocus(true);
    if (p.fontSize && p.fontSize !== 100) setFontSize(p.fontSize);
    if (p.hover)     setHover(true, p.ttsRate || 1);
  });

  // ── Message listener ──────────────────────────────
  chrome.runtime.onMessage.addListener((msg) => {
    switch (msg.action) {
      case 'readPage':      speak(getPageText(), msg.rate || 1); break;
      case 'stop':          stopSpeech(); toggleCaptions(false);   break;
      case 'readImages':    readImages(msg.rate || 1);             break;
      case 'toggleCaptions':toggleCaptions(msg.on);               break;
      case 'setContrast':   setContrast(msg.on);                  break;
      case 'setDark':       setDark(msg.on);                      break;
      case 'setHover':      setHover(msg.on, msg.rate || 1);      break;
      case 'setFocus':      setFocus(msg.on);                     break;
      case 'setFontSize':   setFontSize(msg.value);               break;
    }
  });

})();
