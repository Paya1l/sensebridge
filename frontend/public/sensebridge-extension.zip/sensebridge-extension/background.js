// background.js — SenseBridge service worker

chrome.runtime.onInstalled.addListener(() => {
  console.log('[SenseBridge] Extension installed.');
});

// Handle any background messaging if needed
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  sendResponse({ ok: true });
});
