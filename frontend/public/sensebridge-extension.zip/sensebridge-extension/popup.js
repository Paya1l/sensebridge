// popup.js — SenseBridge Extension

const $ = id => document.getElementById(id);

// ── State ──────────────────────────────────────────────
let state = {
  contrast:   false,
  dark:       false,
  hover:      false,
  focus:      false,
  fontSize:   100,
  ttsRate:    1.0,
  listening:  false,
};

// ── Load saved prefs ───────────────────────────────────
chrome.storage.local.get('sbPrefs', res => {
  if (res.sbPrefs) Object.assign(state, res.sbPrefs);
  applyUI();
});

function save() {
  chrome.storage.local.set({ sbPrefs: state });
}

// ── Apply UI to reflect state ──────────────────────────
function applyUI() {
  setToggle('togContrast', state.contrast);
  setToggle('togDark',     state.dark);
  setToggle('togHover',    state.hover);
  setToggle('togFocus',    state.focus);
  $('fontSize').value   = state.fontSize;
  $('ttsRate').value    = state.ttsRate;
  $('fontSizeVal').textContent = state.fontSize + '%';
  $('ttsRateVal').textContent  = parseFloat(state.ttsRate).toFixed(1) + '×';
}

function setToggle(id, on) {
  const el = $(id);
  if (on) el.classList.add('on');
  else    el.classList.remove('on');
}

// ── Status bar ─────────────────────────────────────────
function setStatus(msg, active = true) {
  const bar = $('statusBar');
  $('statusText').textContent = msg;
  if (active) bar.classList.remove('idle');
  else        bar.classList.add('idle');
}

// ── Send message to content script ────────────────────
function send(msg) {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    if (!tabs[0]) return;
    chrome.tabs.sendMessage(tabs[0].id, msg, () => {
      if (chrome.runtime.lastError) {
        // content script not ready yet — inject and retry
        chrome.scripting.executeScript(
          { target: { tabId: tabs[0].id }, files: ['content.js'] },
          () => chrome.tabs.sendMessage(tabs[0].id, msg)
        );
      }
    });
  });
}

// ── Quick Action buttons ───────────────────────────────
$('btnRead').addEventListener('click', () => {
  send({ action: 'readPage', rate: state.ttsRate });
  setStatus('Reading page aloud…');
});

$('btnStop').addEventListener('click', () => {
  send({ action: 'stop' });
  setStatus('Stopped.', false);
});

$('btnListen').addEventListener('click', () => {
  state.listening = !state.listening;
  send({ action: 'toggleCaptions', on: state.listening });
  if (state.listening) {
    $('btnListen').style.opacity = '0.7';
    setStatus('Live captions active…');
  } else {
    $('btnListen').style.opacity = '1';
    setStatus('Captions off.', false);
  }
});

$('btnAlts').addEventListener('click', () => {
  send({ action: 'readImages', rate: state.ttsRate });
  setStatus('Reading image descriptions…');
});

// ── Toggles ────────────────────────────────────────────
$('togContrast').addEventListener('click', () => {
  state.contrast = !state.contrast;
  setToggle('togContrast', state.contrast);
  send({ action: 'setContrast', on: state.contrast });
  save();
  setStatus(state.contrast ? 'High contrast on.' : 'High contrast off.', false);
});

$('togDark').addEventListener('click', () => {
  state.dark = !state.dark;
  setToggle('togDark', state.dark);
  send({ action: 'setDark', on: state.dark });
  save();
  setStatus(state.dark ? 'Dark mode on.' : 'Dark mode off.', false);
});

$('togHover').addEventListener('click', () => {
  state.hover = !state.hover;
  setToggle('togHover', state.hover);
  send({ action: 'setHover', on: state.hover, rate: state.ttsRate });
  save();
  setStatus(state.hover ? 'Hover-to-read on.' : 'Hover-to-read off.', false);
});

$('togFocus').addEventListener('click', () => {
  state.focus = !state.focus;
  setToggle('togFocus', state.focus);
  send({ action: 'setFocus', on: state.focus });
  save();
  setStatus(state.focus ? 'Focus highlight on.' : 'Focus highlight off.', false);
});

// ── Sliders ────────────────────────────────────────────
$('fontSize').addEventListener('input', e => {
  state.fontSize = parseInt(e.target.value);
  $('fontSizeVal').textContent = state.fontSize + '%';
  send({ action: 'setFontSize', value: state.fontSize });
  save();
});

$('ttsRate').addEventListener('input', e => {
  state.ttsRate = parseFloat(e.target.value);
  $('ttsRateVal').textContent = state.ttsRate.toFixed(1) + '×';
  save();
});

// ── Open app ───────────────────────────────────────────
$('openApp').addEventListener('click', () => {
  chrome.tabs.create({ url: 'http://localhost:3000' });
});
